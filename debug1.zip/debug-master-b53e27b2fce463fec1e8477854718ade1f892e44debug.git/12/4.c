#include<stdio.h>
#define PI 3.14159
int main(){
    double r;
    scanf("%.3lf",&r);
    printf("%.3lf\n", 2 * 3.14 * r);
    printf("%.3lf\n", 3.14 * r * r);
    return 0;
}